<?php

namespace Itc\Hotels\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface {

    public function install( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
        $installer = $setup;

        $installer->startSetup();
        
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_location')
					)->addColumn(
						'location_id',
						\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
						10,
						['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
						'Location ID'
					)->addColumn(
						'lname',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						255,
						['nullable' => false, 'default' => ''],
						'Location Name'
					)->addColumn(
						'status',
					   \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					   1,
					   [],
					   'Status'
					)->addIndex(
						$installer->getIdxName('itc_location', ['location_id']),
						['location_id']       
					);
        $installer->getConnection()->createTable($table);
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable( 'itc_hotels' )
					)->addColumn(
						'hid',
						Table::TYPE_INTEGER,
						null,
						['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
						'Hotel Id'
					)
					->addColumn(
						'hotel_code',
						Table::TYPE_INTEGER,
						null,
						['unsigned' => true, 'nullable' => false],
						'Hotels Code'
					)
					->addColumn(
						'hotel_class',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'Hotel Class'
					)
					->addColumn(
						'hotel_name',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'Hotel Name'
					)
					->addColumn(
						'status',
						Table::TYPE_TEXT,
						255,
						[],
						'Status'
					)->addColumn(
						'location_id',
						Table::TYPE_INTEGER,
						null,
						['unsigned' => true, 'nullable' => false],
						'Location Id'
					)->addForeignKey(
						$installer->getFkName('itc_hotels', 'location_id', 'itc_location', 'location_id'),
						'location_id',
						$installer->getTable('itc_location'),
						'location_id',
						\Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
					)
					->setComment(
				'Sample Post Table'
					);

        $installer->getConnection()->createTable( $table );
        
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_room_type')
					)->addColumn(
						'roomtype_id',
						\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
						null,
						['nullable' => false, 'primary' => true],
						'RoomType ID'
					)->addColumn(
						'room_type_name',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						null,
						['nullable' => false],
						'RoomType Name'
					)->addColumn(
						'room_type_decs',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						null,
						['nullable' => false],
						'RoomType Decs'
					)->setComment(
						'CMS Block To Store Linkage Table'
					);
        $installer->getConnection()->createTable($table);
		
	$table = $installer->getConnection()->newTable(
            $installer->getTable( 'itc_rooms' )
					)->addColumn(
						'room_id',
						Table::TYPE_INTEGER,
						null,
						['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
						'Room ID'
					)
					->addColumn(
						'room_name',
						Table::TYPE_TEXT,
						32,
						[],
						'Room Name'
					)
					->addColumn(
						'room_number',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'Room Number'
					)
					->addColumn(
						'room_description',
						Table::TYPE_TEXT,
						32,
						[],
						'Room Description'
					)
					->addColumn(
						'room_type',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'Room Type'
					)
					->addColumn(
						'room_cost',
						Table::TYPE_DECIMAL,
						'12,4',
						[],
						'Room Cost'
					)
					->addColumn(
						'maxadultcount',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'MaxAdultCount'
					)
					->addColumn(
						'maxchildrencount',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'MaxChildrenCount'
					)
					->addColumn(
						'gallery_id',
						Table::TYPE_TEXT,
						null,
						['unsigned' => true, 'nullable' => false],
						'Gallery ID'
					)
                                          ->addColumn(
						'hid',
						Table::TYPE_INTEGER,
						null,
						['unsigned' => true, 'nullable' => false],
						'Hotel Id'
					)
					->addColumn(
						'roomtype_id',
						Table::TYPE_INTEGER,
						null,
						['nullable' => false],
						'RoomType ID'
					)->addForeignKey(
						$installer->getFkName('itc_rooms', 'roomtype_id', 'itc_room_type', 'roomtype_id'),
						'roomtype_id',
						$installer->getTable('itc_room_type'),
						'roomtype_id',
						\Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
					)
                                         ->addForeignKey(
						$installer->getFkName('itc_rooms', 'hid', 'itc_hotels', 'hid'),
						'hid',
						$installer->getTable('itc_hotels'),
						'hid',
						\Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
					)->setComment(
						'Sample Post Table'
					);

        $installer->getConnection()->createTable( $table );
			       
		/* itc_amenities Table */
		$table = $installer->getConnection()->newTable(
            $installer->getTable('itc_amenities')
					)->addColumn(
						'amenities_id',
						\Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
						null,
						['nullable' => false, 'primary' => true],
						'Amenities ID'
					)->addColumn(
						'amenities_name',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						null,
						['nullable' => false],
						'Amenities Name'
					)->addColumn(
						'amenities_icon',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						null,
						['nullable' => false],
						'Amenities Icon'
					)->addColumn(
						'amenities_decs',
						\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
						null,
						['nullable' => false],
						'Amenities Decs'
					)->setComment(
						'Amenities Table'
					);
        $installer->getConnection()->createTable($table);		
				
        $installer->endSetup();
    }
}
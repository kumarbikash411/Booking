<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Itc\Hotels\Model\Room\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Itc\Hotels\Model\Hotels;

/**
 * Class PageLayout
 */
class Hotelsid implements OptionSourceInterface
{
    /**
     * @var \Magento\Framework\View\Model\PageLayout\Config\BuilderInterface
     */
    protected $hotels;

    /**
     * @var array
     */
    protected $options;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(Hotels $hotels)
    {
        $this->hotels = $hotels;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }

        $hotelOptions = $this->hotels->getCollection()->getData();
        $options = [];
        foreach ($hotelOptions as $val) {
			$value = $val['customer_group'];
			$key = $val['hotel_id'];
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        $this->options = $options;

        return $this->options;
    }
}

<?php


namespace Itc\Hotels\Model;



class Amenity extends \Magento\Framework\Model\AbstractModel  
{   
	protected function _construct()
	{
		$this->_init('Itc\Hotels\Model\ResourceModel\Amenity');
	}
	
}
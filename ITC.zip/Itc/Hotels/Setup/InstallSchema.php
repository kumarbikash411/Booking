<?php

namespace Itc\Hotels\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface {

    public function install( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()->newTable(
            $installer->getTable( 'itc_hotels' )
        )->addColumn(
					'hotel_id',
					Table::TYPE_INTEGER,
					null,
					['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
					'Entity Id'
				)
                ->addColumn(
					'order_id',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'Order Id'
				)
                ->addColumn(
                    'customer_group',
                    Table::TYPE_TEXT,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Customer Group'
                )
                ->addColumn(
                    'purchase_date',
                    Table::TYPE_DATETIME,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Purchased Date'
                )
				->addColumn(
					'order_base_grand_total',
					Table::TYPE_DECIMAL,
					'12,4',
					[],
					'Order Grand Total'
				)
                ->addColumn(
                    'billing_name',
                    Table::TYPE_TEXT,
                    32,
                    [],
                    'Billing Name'
                )
                ->addColumn(
                    'status',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'Status'
                )
				->addColumn(
					'payment_method',
					Table::TYPE_TEXT,
					255,
					[],
					'Payment Method'
				)->setComment(
            'Sample Post Table'
        );

        $installer->getConnection()->createTable( $table );
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable( 'itc_gallery' )
        )->addColumn(
					'entity_id',
					Table::TYPE_INTEGER,
					null,
					['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
					'Entity Id'
				)
                ->addColumn(
					'order_id',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'Order Id'
				)
                ->addColumn(
                    'customer_group',
                    Table::TYPE_TEXT,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Customer Group'
                )
                ->addColumn(
                    'purchase_date',
                    Table::TYPE_DATETIME,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Purchased Date'
                )
				->addColumn(
					'order_base_grand_total',
					Table::TYPE_DECIMAL,
					'12,4',
					[],
					'Order Grand Total'
				)
                ->addColumn(
                    'billing_name',
                    Table::TYPE_TEXT,
                    32,
                    [],
                    'Billing Name'
                )
                ->addColumn(
                    'status',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'Status'
                )
				->addColumn(
					'payment_method',
					Table::TYPE_TEXT,
					255,
					[],
					'Payment Method'
				)->setComment(
            'Sample Post Table'
        );
		/* itc_amenities Table */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_amenities')
        )->addColumn(
            'amenities_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            ['nullable' => false, 'primary' => true],
            'Amenities ID'
        )->addColumn(
            'amenities_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => false],
            'Amenities Name'
        )->addColumn(
            'amenities_icon',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => false],
            'Amenities Icon'
        )->addColumn(
            'amenities_decs',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => false],
            'Amenities Decs'
        )->setComment(
            'Amenities Table'
        );
        $installer->getConnection()->createTable($table);
		/* Room Type Table */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_room_type')
        )->addColumn(
            'roomtype_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'RoomType ID'
        )->addColumn(
            'room_type_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => false],
            'RoomType Name'
        )->addColumn(
            'room_type_decs',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => false],
            'RoomType Decs'
        )->setComment(
            'CMS Block To Store Linkage Table'
        );
        $installer->getConnection()->createTable($table);
		/* Room Table
        RoomID
		RoomName
		RoomNumber
		RoomDescription
		RoomType
		RoomCost
		MaxAdultCount
		MaxChildrenCount
		HotelID
		GalleryID
		RoomTypeID
		*/
		$installer->getConnection()->createTable( $table );
		$table = $installer->getConnection()->newTable(
            $installer->getTable( 'itc_rooms' )
        )->addColumn(
					'room_id',
					Table::TYPE_INTEGER,
					null,
					['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
					'Room ID'
				)
				->addColumn(
                    'room_name',
                    Table::TYPE_TEXT,
                    32,
                    [],
                    'Room Name'
                )
                ->addColumn(
					'room_number',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'Room Number'
				)
				->addColumn(
                    'room_description',
                    Table::TYPE_TEXT,
                    32,
                    [],
                    'Room Description'
                )
                ->addColumn(
                    'room_type',
                    Table::TYPE_TEXT,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Room Type'
                )
				->addColumn(
					'room_cost',
					Table::TYPE_DECIMAL,
					'12,4',
					[],
					'Room Cost'
				)
				->addColumn(
					'maxadultcount',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'MaxAdultCount'
				)
				->addColumn(
					'maxchildrencount',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'MaxChildrenCount'
				)
				->addColumn(
					'hotel_id',
					Table::TYPE_INTEGER,
					null,
					['unsigned' => true, 'nullable' => false],
					'Hotel ID'
				)
				->addColumn(
					'gallery_id',
					Table::TYPE_TEXT,
					null,
					['unsigned' => true, 'nullable' => false],
					'Gallery ID'
				)->addColumn(
					'roomtype_id',
					Table::TYPE_INTEGER,
					null,
					['nullable' => false],
					'RoomType ID'
				)->addIndex(
					$installer->getIdxName('itc_rooms', ['hotel_id']),
					['hotel_id']
				)->addIndex(
					$installer->getIdxName('itc_rooms', ['roomtype_id']),
					['roomtype_id']
				)->addForeignKey(
					$installer->getFkName('itc_rooms', 'hotel_id', 'itc_hotels', 'hotel_id'),
					'hotel_id',
					$installer->getTable('itc_hotels'),
					'hotel_id',
					\Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
				)->addForeignKey(
							$installer->getFkName('itc_rooms', 'roomtype_id', 'itc_room_type', 'roomtype_id'),
							'roomtype_id',
							$installer->getTable('itc_room_type'),
							'roomtype_id',
							\Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
				)->setComment(
					'Sample Post Table'
				);

        $installer->getConnection()->createTable( $table );
		
        $installer->endSetup();
    }
}
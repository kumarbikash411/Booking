<?php
/**
 * Hello World
    *
    * @category    QaisarSatti
    * @package     QaisarSatti_HelloWorld
    * @author      Muhammad Qaisar Satti
    * @Email       qaisarssatti@gmail.com
    *
 */
namespace Itc\Hotels\Controller\Adminhtml\Index;

class Index extends \Magento\Backend\App\Action
{
    
    protected $resultPageFactory;
	protected $sus;

    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Itc\Hotels\Model\Hotels $sus
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->coreRegistry = $coreRegistry;
		$this->sus = $sus;
        parent::__construct($context);
    }

    
    public function execute()
    {
		//$this->sus->say();
		//$hh = $this->_objectManager->get('');
		//$hh->say();
        $resultPage = $this->resultPageFactory->create();
        $this->initPage($resultPage)->getConfig()->getTitle()->prepend(__('Itc Hotels'));
        return $resultPage;
    }
    protected function initPage($resultPage)
    {
         $resultPage->setActiveMenu('Itc_Hotels::hotels1')
             ->addBreadcrumb(__('Itc Hotels'), __('Itc Hotels'))
             ->addBreadcrumb(__('Itc Hotels'), __('Itc Hotels'));

         return $resultPage;
    }

 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Itc_Hotels::hotels1');
    }
}
<?php
/**
 *
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Itc\Hotels\Controller\Adminhtml\Room;

use Magento\Backend\App\Action;
use Itc\Hotels\Model\Room;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Itc_Hotels::save';

   
    protected $dataPersistor;

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		//$roomname = $this->getRequest()->getParams();
		//print_r($roomname);exit;
        $roomname = $this->getRequest()->getParam('room_name');
		$roomnumber = $this->getRequest()->getParam('room_number');
		$roomtype = $this->getRequest()->getParam('room_type');
		$roomcost = $this->getRequest()->getParam('room_cost');
		$maxadultcount = $this->getRequest()->getParam('maxadultcount');
		$maxchildrencount = $this->getRequest()->getParam('maxchildrencount');
		$hotelid = $this->getRequest()->getParam('hotel_id');
		$galleryid = $this->getRequest()->getParam('gallery_id');
		$roomtypeid = $this->getRequest()->getParam('roomtype_id');
		$roomdescription = $this->getRequest()->getParam('room_description');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
            $model = $this->_objectManager->create('Itc\Hotels\Model\Room');
            $model->setData('room_name', $roomname);
			$model->setData('room_number', $roomnumber);
			$model->setData('room_type', $roomtype);
			$model->setData('room_cost', $roomcost);
			$model->setData('maxadultcount', $maxadultcount);
			$model->setData('maxchildrencount', $maxchildrencount);
			$model->setData('hotel_id', $hotelid);
			$model->setData('gallery_id', $galleryid);
			$model->setData('roomtype_id', $roomtypeid);
			$model->setData('room_description', $roomdescription);
            $model->save();
            return $resultRedirect->setPath('*/*/');
    }
}

<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace ITC\Hotels\Model\Room\Source;

use Magento\Framework\Data\OptionSourceInterface;
use ITC\Hotels\Model\Hotels;

/**
 * Class Theme
 */
class Hotelsid implements OptionSourceInterface
{
   
    protected $hotelsid;

    /**
     * @var array
     */
    protected $options;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(Hotels $hotelsid)
    {
        $this->hotelsid = $hotelsid;
    }
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }

        $hotelsOptions = $this->hotelsid->getCollection()->getData();
        $options = [];
        foreach ($hotelsOptions as $val) {
            $value = $val['hname'];
            $key = $val['hid'];
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        $this->options = $options;

        return $this->options;
    }
}
<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace ITC\Hotels\Model\Room\Source;

use Magento\Framework\Data\OptionSourceInterface;
use ITC\Hotels\Model\Roomtype;

/**
 * Class Theme
 */
class roomtypeid implements OptionSourceInterface
{
   
    protected $roomtypeid;

    /**
     * @var array
     */
    protected $options;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(Roomtype $roomtypeid)
    {
        $this->roomtypeid = $roomtypeid;
    }
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }

        $roomtypeOptions = $this->roomtypeid->getCollection()->getData();
        $options = [];
        foreach ($roomtypeOptions as $val) {
            $value = $val['rtype_name'];
            $key = $val['rtype_id'];
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        $this->options = $options;

        return $this->options;
    }
}
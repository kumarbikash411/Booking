<?php

/**
 * ITCCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the 
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
  * http://itccommerce.com/license-agreement.txt
 *
 * @category    ITC
 * @package     ITC_Hotels
 * @author      ITCCommerce Core Team <connect@itccommerce.com >
 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)
 * @license      http://itccommerce.com/license-agreement.txt
 */

namespace ITC\Hotels\Model;

class RoomAmenities extends \Magento\Framework\Model\AbstractModel 

{

	/**

	 *@var Magento\Framework\Registry

	 */

	

	protected $_coreRegistry;

	

	/**

	 *@var Magento\Framework\Model\Context

	 */

	

	protected $_context;

	

	/**

	 *@var Magento\Framework\UrlInterface

	 */

	

	protected $urlBuilder;

	

	/**

	 *@var Magento\Framework\ObjectManagerInterface

	 */

	

	protected $objectManager;

	

	/**

	 * @param Magento\Framework\ObjectManagerInterface

	 * @param Magento\Framework\Model\Context

	 * @param Magento\Framework\UrlInterface

	 * @param Magento\Framework\Registry

	 * @param Magento\Framework\Model\ResourceModel\AbstractResource

	 * @param Magento\Framework\Data\Collection\AbstractDb

	 */

	

	public function __construct(

		\Magento\Framework\Model\Context $context,

		\Magento\Framework\ObjectManagerInterface $objectManager,

		\Magento\Framework\UrlInterface  $urlBuilder,

        \Magento\Framework\Registry $registry,

        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,

        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null

		) 

	{

		$this->objectManager = $objectManager;

		$this->_context = $context;

		$this->urlBuilder = $urlBuilder;

		$this->resource = $resource;

		$this->resourceCollection = $resourceCollection;

		$this->_coreRegistry = $registry;

		parent::__construct($context,$registry,$resource,$resourceCollection);

	}

	

	/**

	 *@var construct

	 */

	protected function _construct()

	{

		$this->_init('ITC\Hotels\Model\ResourceModel\RoomAmenities');

	}

	


}
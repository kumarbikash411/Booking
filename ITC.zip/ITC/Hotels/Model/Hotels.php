<?php
/**
 * Copyright © 2016 ITC. All rights reserved.
 */
 
namespace ITC\Hotels\Model;
 
class Hotels extends \Magento\Framework\Model\AbstractModel
{
     /**
     * Cache tag
     * 
     * @var string
     */
    const CACHE_TAG = 'itc_hotels_hotels';
	
	
    protected function _construct()
    {
        $this->_init('ITC\Hotels\Model\ResourceModel\Hotels');
    }
	
	
    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getHid()];
    }
	
    /**
     * get entity default values
     *
     * @return array
     */
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
 
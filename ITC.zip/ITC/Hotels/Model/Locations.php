<?php
/**
 * Copyright © 2016 ITC. All rights reserved.
 */
 
namespace ITC\Hotels\Model;
 
class Locations extends \Magento\Framework\Model\AbstractModel
{
    
    protected function _construct()
    {
        $this->_init('ITC\Hotels\Model\ResourceModel\Locations');
    }
}
 
<?php
namespace ITC\Hotels\Model;
class Room extends \Magento\Framework\Model\AbstractModel  
{   
	protected function _construct()
	{
		$this->_init('ITC\Hotels\Model\ResourceModel\Room');
	}
	
}
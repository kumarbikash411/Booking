<?php

namespace ITC\Hotels\Model\Hotels;
  
use ITC\Hotels\Model\ResourceModel\Hotels\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
  
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
	
    /**
	* @var array
    */
    protected $loadedData;
 
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $hotelsCollectionFactory,
		DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $hotelsCollectionFactory->create();
		$this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
 
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \ITC\Hotels\Model\Hotels $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getHid()] = $block->getData();
        }

        $data = $this->dataPersistor->get('itc_hotels');
        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);
            $this->loadedData[$block->getHid()] = $block->getData();
            $this->dataPersistor->clear('itc_hotels');
        }
        return $this->loadedData;				 
    }
}
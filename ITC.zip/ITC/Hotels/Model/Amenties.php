<?php

namespace ITC\Hotels\Model;

class Amenties extends \Magento\Framework\Model\AbstractModel
{

	public function __construct(

		\Magento\Framework\Model\Context $context,

		\Magento\Framework\ObjectManagerInterface $objectManager,

		\Magento\Framework\UrlInterface  $urlBuilder,

        \Magento\Framework\Registry $registry,

        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,

        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null

		) 

	{

		$this->objectManager = $objectManager;

		$this->_context = $context;

		$this->urlBuilder = $urlBuilder;

		$this->resource = $resource;

		$this->resourceCollection = $resourceCollection;

		$this->_coreRegistry = $registry;

		parent::__construct($context,$registry,$resource,$resourceCollection);

	}

	protected function _construct()

	{

		$this->_init('ITC\Hotels\Model\ResourceModel\Amenties');

	}


}
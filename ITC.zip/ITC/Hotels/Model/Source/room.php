<?php

namespace ITC\Hotels\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
* Class Status
*/
    class Location implements OptionSourceInterface
{
	protected $_locationCollectionFactory;
	
	public function __construct(      
      \ITC\Hotels\Model\ResourceModel\Locations\CollectionFactory $locationCollectionFactory
	){        
      $this->_locationCollectionFactory = $locationCollectionFactory;      
    }
	/**
	 * Get options
	 *
	 * @return array
	 */
	public function toOptionArray()
	{
        $locationsArray = $this->_locationCollectionFactory->create()
							->load()
							->toArray();		
        $locations = array();	
        foreach ($locationsArray['items'] as $locationLid => $location) {
            if (isset($location['lname'])){
                $locations[] = array(
                    'label' => $location['lname'],                    
                    'value' => $location['lid'],
                );
            }
        }
        return $locations;
	}
}
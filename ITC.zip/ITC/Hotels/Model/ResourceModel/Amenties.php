<?php

namespace ITC\Hotels\Model\ResourceModel;



class Amenties extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb

{

	protected function _construct()

	{

		//grid_record is table and grid_record_id is primary key of this table

		$this->_init('itc_booking_amenities', 'id');

	}


	public function checkIdentifier($identifier)

	{

		$select = $this->_getLoadByIdentifierSelect($identifier);

		return $this->getConnection()->fetchOne($select);

	}

	

	/**

	 * Retrieve load select with filter by identifier, store and activity

	 *

	 * @param string $identifier

	 * @param int|array $store

	 * @param int $isActive

	 * @return \Magento\Framework\DB\Select

	 */

	protected function _getLoadByIdentifierSelect($identifier)

	{

		 $select = $this->getConnection()->select()->from(

            ['blog_category' => $this->getMainTable()]

        )->where(

				'blog_category.url_key = ?',

				$identifier

		);

		return $select;

	}

	

	/*  */

	public function validate($object, $request)

	{

		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();

		$attributeSet = $objectManager->create('ITC\Blog\Model\Blogcat')->getCollection()

						->addFieldToFilter('url_key',array('like'=>$request->getParam('url_key')));

						

		if($object->getId())				

			$attributeSet->addFieldToFilter('id',array('nin'=>$object->getId()));

						

		if(count($attributeSet)>0){

			return ['url_key' => 'Url key already exists '];

		}

		

		return true;

	}

}


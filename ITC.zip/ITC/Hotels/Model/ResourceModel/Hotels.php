<?php
namespace ITC\Hotels\Model\ResourceModel;
 
class Hotels extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    
    protected function _construct()
    {
        $this->_init('itc_hotels', 'hid');
    }
}

<?php

/**
 * ITCCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the 
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
  * http://itccommerce.com/license-agreement.txt
 *
 * @category    ITC
 * @package     ITC_Hotels
 * @author      ITCCommerce Core Team <connect@itccommerce.com >
 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)
 * @license      http://itccommerce.com/license-agreement.txt
 */



namespace ITC\Hotels\Model\ResourceModel;



class RoomCategoryRelation extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb

{

	protected function _construct()

	{

		//itc_booking_roomtypes is table and roomtype_id is primary key of this table

		$this->_init('itc_booking_room_type_category_relation', 'id');

	}

	

}


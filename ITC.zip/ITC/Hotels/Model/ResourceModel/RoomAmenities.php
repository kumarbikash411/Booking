<?php




namespace ITC\Hotels\Model\ResourceModel;



class RoomAmenities extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb

{

	protected function _construct()

	{

		$this->_init('itc_room_amenities', 'ra_id');

	}


}
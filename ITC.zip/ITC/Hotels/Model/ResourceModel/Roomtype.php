<?php




namespace ITC\Hotels\Model\ResourceModel;



class Roomtype extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb

{

	protected function _construct()

	{

		

		$this->_init('itc_room_type', 'rtype_id');

	}

	

}


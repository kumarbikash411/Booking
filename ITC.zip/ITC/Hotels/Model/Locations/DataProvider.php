<?php

namespace ITC\Hotels\Model\Locations;
  
use ITC\Hotels\Model\ResourceModel\Locations\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
  
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
	
    /**
	* @var array
    */
    protected $loadedData;
 
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $locationsCollectionFactory,
		DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $locationsCollectionFactory->create();
		$this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
 
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \ITC\Hotels\Model\Locations $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getHid()] = $block->getData();
        }

        $data = $this->dataPersistor->get('itc_locations');
        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);
            $this->loadedData[$block->getHid()] = $block->getData();
            $this->dataPersistor->clear('itc_locations');
        }
        return $this->loadedData;				 
    }
}
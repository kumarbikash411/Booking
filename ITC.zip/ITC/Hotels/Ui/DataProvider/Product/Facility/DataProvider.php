<?php
/**
 * ItcCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the 
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://itccommerce.com/license-agreement.txt
 *
 * @category    Itc
 * @package     Itc_Booking
 * @author   	ItcCommerce Core Team <connect@itccommerce.com >
 * @copyright   Copyright ItcCommerce (http://itccommerce.com/)
 * @license      http://itccommerce.com/license-agreement.txt
 */
namespace Itc\Hotels\Ui\DataProvider\Product\Facility;

/**
 * Class Facilities Data prodvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{

    protected $addFieldStrategies;


    protected $addFilterStrategies;
    /**
     * Construct
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param Pincode $collectionFactory
     * @param \Magento\Ui\DataProvider\AddFieldToCollectionInterface[] $addFieldStrategies
     * @param \Magento\Ui\DataProvider\AddFilterToCollectionInterface[] $addFilterStrategies
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        \Itc\Hotels\Model\ResourceModel\Facilities\CollectionFactory $collection,
        \Magento\Framework\App\RequestInterface $RequestInterface,
        array $addFieldStrategies = [],
        array $addFilterStrategies = [],
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collection->create();
        $this->addFieldStrategies = $addFieldStrategies;
        $this->addFilterStrategies = $addFilterStrategies;
        $this->_request = $RequestInterface;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {

    	if (!$this->getCollection()->isLoaded()) {
    		$this->getCollection()->load();
    	}
        $itemscollection = $this->getCollection()->addFieldToFilter('status',1)->addFieldToFilter('type','hotel');
    	
    	return [
    			'totalRecords' =>  count($itemscollection),
    			'items' => $itemscollection->getData(),
    	];
    }


    /**
     * Add field to select
     *
     * @param string|array $field
     * @param string|null $alias
     * @return void
     */
    public function addField($field, $alias = null)
    {
        if (isset($this->addFieldStrategies[$field])) {
            $this->addFieldStrategies[$field]->addField($this->getCollection(), $field, $alias);
        } else {
            parent::addField($field, $alias);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function addFilter(\Magento\Framework\Api\Filter $filter)
    {
        if (isset($this->addFilterStrategies[$filter->getField()])) {
            $this->addFilterStrategies[$filter->getField()]
                ->addFilter(
                    $this->getCollection(),
                    $filter->getField(),
                    [$filter->getConditionType() => $filter->getValue()]
                );
        } else {
            parent::addFilter($filter);
        }
    }
}
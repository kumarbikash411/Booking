<?php

/**

 * ITCCommerce

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the 

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://itccommerce.com/license-agreement.txt

 *

 * @category    ITC

 * @package     ITC_Hotels

 * @author   	ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)

 * @license      http://itccommerce.com/license-agreement.txt

 */

namespace ITC\Hotels\Controller\Adminhtml\Roomtype;



use Magento\Backend\App\Action;



class Delete extends \Magento\Backend\App\Action

{

	/**

	 * @var execute

	 */

	public function execute()

	{

		$id = $this->getRequest()->getParam('id');
	
		$model = $this->_objectManager->create('ITC\Hotels\Model\Roomtype')->load($id);
		$model->setId($id)->delete();
		$this->_redirect('hotels/roomtype/index');
		$this->messageManager->addSuccess(__('Record has been deleted'));

	}

}
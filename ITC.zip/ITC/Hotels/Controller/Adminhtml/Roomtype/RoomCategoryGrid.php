<?php

namespace ITC\Hotels\Controller\Adminhtml\Roomtype;



use Magento\Backend\App\Action\Context;

use Magento\Framework\View\Result\PageFactory;

use Magento\Backend\App\Action;



class RoomCategoryGrid extends \Magento\Backend\App\Action

{

	/**

     * @var \Magento\Framework\View\Result\PageFactory

     */

    protected $resultPageFactory;

	/**

     * $_objectManager

     *

     * @var \Magento\Framework\App\ObjectManager $objectManager

     */

    protected $_objectManager;



	public function __construct(

		\Magento\Backend\App\Action\Context $context,

		\Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {



    	parent::__construct($context);

    	$this->resultPageFactory = $resultPageFactory;

    	$this->_objectManager =  $context->getObjectManager();

    }

	

	/**

	 * Index action

	 *

	 * @return void

	 */

	public function execute()
	{

			$resultPage = $this->resultPageFactory->create();

			$resultPage->setActiveMenu('ITC_Hotels::booking_room_category');

			$resultPage->addBreadcrumb(__('Add  Room Type'), __('Create Room Category'));

			$resultPage->getConfig()->getTitle()->prepend(__('Create Room Category'));

			return $resultPage;

		
	}

	protected function _isAllowed()

	{

		return $this->_authorization->isAllowed('ITC_Hotels::booking_room_category');

	}

}
<?php

/**

 * ITCCommerce

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the 

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://itccommerce.com/license-agreement.txt

 *

 * @category    ITC

 * @package     ITC_Hotels

 * @author   	ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)

 * @license      http://itccommerce.com/license-agreement.txt

 */



namespace ITC\Hotels\Controller\Adminhtml\Roomtype;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

 

class Grid extends \Magento\Backend\App\Action

{

    /**

     * @var PageFactory

     */

    protected $resultPageFactory;

    /**

     * @param Context $context

     * @param PageFactory $resultPageFactory

     */

    public function __construct(

        Context $context,

        PageFactory $resultPageFactory

    ) {

        parent::__construct($context);

        $this->resultPageFactory = $resultPageFactory;

    }

 

    /**

     * Index action

     *

     * @return void

     */

    public function execute()

    {
		
    	$resultPage = $this->resultPageFactory->create();

        return $resultPage;

    }

	

	

}


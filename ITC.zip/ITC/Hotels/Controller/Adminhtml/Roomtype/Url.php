<?php

namespace ITC\Hotels\Controller\Adminhtml\Roomtype;



use Magento\Backend\App\Action\Context;

use Magento\Framework\View\Result\PageFactory;

use Magento\Backend\App\Action;


class Url extends \Magento\Backend\App\AbstractAction

{

    protected $resultPageFactory;

	

    protected $_objectManager;

    

	public function __construct(

		\Magento\Backend\App\Action\Context $context,

		\Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {



    	parent::__construct($context);

    	$this->resultPageFactory = $resultPageFactory;

    	$this->_objectManager =  $context->getObjectManager();

    }


	 public function execute()

	 {

	 	$url_key = $this->getRequest()->getParam('url_key');

	 	$collection = $this->_objectManager->create('ITC\Blog\Model\Blogcat')->getCollection()

	 				  ->addFieldToFilter('url',$url_key);

	 

	 }

}
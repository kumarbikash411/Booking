<?php

/**

 * ITCCommerce

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the 

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://itccommerce.com/license-agreement.txt

 *

 * @category    ITC

 * @package     ITC_Hotels

 * @author   	ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)

 * @license      http://itccommerce.com/license-agreement.txt

 */

namespace ITC\Hotels\Controller\Adminhtml\Roomtype;



use Magento\Backend\App\Action\Context;

use Magento\Framework\View\Result\PageFactory;

use Magento\Backend\App\Action;



/**

 *  category profile  Controller

 *

 * @author     ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 */

class Validate extends \Magento\Backend\App\AbstractAction

{

	/**

	 * @var \Magento\Framework\Controller\Result\JsonFactory

	 */

	protected $resultJsonFactory;

	

	/**

	 * @var \Magento\Framework\View\LayoutFactory

	 */

	protected $layoutFactory;

	/**

	 * @var objectManager

	 */

	protected $productFactory;

	

	/**

	 * @var \Magento\Catalog\Model\Product\Validator

	 */

	protected $productValidator;

	

	 /**

     * @var objectManager

     */

    protected $_objectManager;



	/**

	 * @var PageFactory

	 */

	protected $resultPageFactory;

	

	/**

	 * @var Magento\Backend\App\Action\Context

	 * @var Magento\Framework\Controller\ResultFactory

	 */

	public function __construct(

			\Magento\Backend\App\Action\Context $context,

			\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,

			\Magento\Framework\View\LayoutFactory $layoutFactory
	) {

		$this->resultJsonFactory = $resultJsonFactory;

		$this->layoutFactory = $layoutFactory;

		$this->_objectManager = $objectInterface;

		$this->resultPageFactory = $resultPageFactory;

		parent::__construct($context);

	}

	/**

     * Validate product

     *

     * @return \Magento\Framework\Controller\Result\Json

     * @SuppressWarnings(PHPMD.CyclomaticComplexity)

     * @SuppressWarnings(PHPMD.NPathComplexity)

     */

    public function execute()

    {

	



      

    }

}
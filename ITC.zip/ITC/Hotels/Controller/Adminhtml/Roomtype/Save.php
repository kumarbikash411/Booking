<?php
 

namespace ITC\Hotels\Controller\Adminhtml\Roomtype;

use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action
{
	/**
	 * @var \Magento\Backend\Model\View\Result\Forward
	 */
	protected $_objectManager;
	
	/**
	 * @var \Magento\Backend\Model\View\Result\Forward
	 */
	protected $resultRedirectFactory;
	
	/**
	 * @param Magento\Framework\App\Action\Context
	 * @param Magento\Backend\Model\View\Result\Redirect
	 * @param Magento\Framework\Controller\Result\ForwardFactory
	 * @param Magento\Framework\View\Result\PageFactory
	 */
	
	public function __construct(\Magento\Backend\App\Action\Context $context,
			\Magento\Backend\Model\View\Result\Redirect $resultRedirectFactory ,
			\Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory,
			\Magento\Framework\View\Result\PageFactory $resultPageFactory)
	{
		$this->resultRedirectFactory = $resultRedirectFactory;
		$this->resultForwardFactory= $resultForwardFactory;
		$this->resultPageFactory = $resultPageFactory;
		parent::__construct($context);
	}
	public function execute()
    {
    	$resultRedirect = $this->resultRedirectFactory->create();
		$id=$this->getRequest()->getParam('id');
		$data=$this->getRequest()->getPost();

    	if($id==''){
    		$model=$this->_objectManager->create('ITC\Hotels\Model\Roomtype');
    	}else{
    		$model=$this->_objectManager->create('ITC\Hotels\Model\Roomtype')->load($id);
    	}	
    	$model->setData('status',$data['status'])
    		->setData('title',$data['title'])
    		->setData('max_allowed_child',$data['max_allowed_child'])
    		->setData('min_allowed_child',$data['min_allowed_child'])
    		->save();

    	$roomTypeModel = $this->_objectManager->create('ITC\Hotels\Model\Roomtype');

	    $roomTypeId = $roomTypeModel->load($data['title'],'title')->getId();
            
            
	    
      
    	$resultRedirect = $this->resultRedirectFactory->create();
    	$this->_redirect('hotels/roomtype/index');
    	$this->messageManager->addSuccess('You have successfully saved room type.');
	if ($this->getRequest()->getParam('back'))
	{
	   	return $resultRedirect->setPath('*/*/edit', ['id' => $model['id'], '_current' => true]);
	}else{
		$this->_redirect('hotels/roomtype/index');
	}
	  
	}
}


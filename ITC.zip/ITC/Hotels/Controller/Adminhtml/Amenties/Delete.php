<?php
namespace ITC\Hotels\Controller\Adminhtml\Amenties;



use Magento\Backend\App\Action;



class Delete extends \Magento\Backend\App\Action

{

	public function execute()
	{

		$id = $this->getRequest()->getParam('id');
		
		$model = $this->_objectManager->create('ITC\Hotels\Model\Amenties')->load($id);
		
		$model->setId($id)->delete();
		
		$this->_redirect('hotels/amenties/index');
		
		$this->messageManager->addSuccess(__('Record has been deleted'));
		

	}

}
<?php



namespace ITC\Hotels\Controller\Adminhtml\Amenties;



use Magento\Backend\App\Action\Context;

use Magento\Framework\View\Result\PageFactory;

use Magento\Backend\App\Action;




class Validate extends \Magento\Backend\App\AbstractAction

{

	

	protected $resultJsonFactory;

	

	

	protected $layoutFactory;

	

	protected $productFactory;

	

    protected $_objectManager;



	

	protected $resultPageFactory;

	

	

	public function __construct(

			\Magento\Backend\App\Action\Context $context,

			\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,

			\Magento\Framework\View\LayoutFactory $layoutFactory

	) {

		$this->resultJsonFactory = $resultJsonFactory;

		$this->layoutFactory = $layoutFactory;

		$this->_objectManager = $context->getObjectManager();

		$this->resultPageFactory = $context->getResultFactory();

		parent::__construct($context);

	}

	/**

     * Validate product

     *

     * @return \Magento\Framework\Controller\Result\Json

     * @SuppressWarnings(PHPMD.CyclomaticComplexity)

     * @SuppressWarnings(PHPMD.NPathComplexity)

     */

    public function execute()

    {


    }

}
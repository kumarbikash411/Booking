<?php

/**

 * ITCCommerce

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the 

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://itccommerce.com/license-agreement.txt

 *

 * @category    ITC

 * @package     ITC_Hotels

 * @author   	ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)

 * @license      http://itccommerce.com/license-agreement.txt

 */

namespace ITC\Hotels\Controller\Adminhtml\amenties;



use Magento\Backend\App\Action;



/**

 * massDelete category Controller

 *

 * @author     ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 */

class massDelete extends \Magento\Backend\App\Action

{

	

	/**

	 * @param execute

	 */

	

	public function execute()

	{

		$data = $this->getRequest()->getParams();

		if ($data)

		{

			$postData = $this->getRequest()->getPost();

			$id = $this->getRequest()->getParam('id');

			$productDeleted = 0;

			foreach($id as $val)

			{

				$model = $this->_objectManager->create('ITC\Hotels\Model\Amenties')->load($val);	

				$model->setId($val)->delete();

				$productDeleted++;

			}

			$this->_redirect('hotels/amenties/index');

			$this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $productDeleted));

		}

	}

}  


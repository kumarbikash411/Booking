<?php
 
namespace ITC\Hotels\Controller\Adminhtml\Amenties;


class MassStatus extends \Magento\Backend\App\Action
{
    /**
     * 
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context
       
    ) {
        parent::__construct($context);
    }

    /**
     * Update roomtype status action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $data = $this->getRequest ()->getParams ();
		if ($data) {
			
			$postData = $this->getRequest ()->getPost ();
			
			$ids = $this->getRequest ()->getParam ( 'id' );

			$status = $this->getRequest ()->getParam ( 'status' );

			foreach ( $ids as $id ) {
				
				$facilitydata = $this->_objectManager->create ( 'ITC\Hotels\Model\Amenties' )->load ( $id );
		
				$facilitydata->setData ( 'status', $status )->save ();
			}   
        }   
        return $this->_redirect('hotels/amenties/index');
    }
}

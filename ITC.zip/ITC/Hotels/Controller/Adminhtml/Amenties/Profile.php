<?php

namespace ITC\Hotels\Controller\Adminhtml\Amenties;

use Magento\Backend\App\Action\Context;



use Magento\Backend\App\Action;


class Profile extends \Magento\Backend\App\AbstractAction

{

	protected $_auth;

	
	public function __construct(Action\Context $context) 

	{

		parent::__construct($context);

	}

	

	/**

	 * @param execute

	 */

	 public function execute()

	 {

	 	$email=$this->getRequest()->getParam('email');

	 	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();

	 	$collection = $objectManager->create('Magento\Customer\Model\Customer')

	 		->setWebsiteId(1)

	 		->loadByEmail($email);

	 	$data=$collection->getEntityId();

	 	echo $data;

	 }

}
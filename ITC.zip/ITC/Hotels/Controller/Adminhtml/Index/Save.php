<?php

namespace ITC\Hotels\Controller\Adminhtml\Index;

use Magento\Framework\App\Filesystem\DirectoryList;
use ITC\Hotels\Model\Hotels;

class Save extends \ITC\Hotels\Controller\Adminhtml\Hotels
{
    public function execute()
    {
       $resultRedirect = $this->resultRedirectFactory->create();	   
	   $data = $this->getRequest()->getPostValue();
	  
       if (isset($data['contact'])) {		   
			//$locationId = array("locationid" => 1);			
			//$finalArray = array_merge($data['contact'],$locationId); 
		    $model = $this->_objectManager->create('ITC\Hotels\Model\Hotels');
			$model->setData($data['contact']);
			$model->save();
	   }   
	   $this->_redirect('*/*/');
    }
}

<?php

namespace ITC\Hotels\Controller\Adminhtml\Index;


class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory;
	protected $hotels;

    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
		//\ITC\Hotels\Model\Suspected $hotels
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->coreRegistry = $coreRegistry;
		//$this->hotels = $hotels;
        parent::__construct($context);
    }

    
    public function execute()
    {
		//$this->hotels->say();
		//$hh = $this->_objectManager->get('');
		//$hh->say();
        $resultPage = $this->resultPageFactory->create();
        $this->initPage($resultPage)->getConfig()->getTitle()->prepend(__('ITC Hotels'));
        return $resultPage;
    }
    protected function initPage($resultPage)
    {
         $resultPage->setActiveMenu('ITC_Hotels::hotels1')
             ->addBreadcrumb(__('ITC Hotels'), __('ITC Hotels'))
             ->addBreadcrumb(__('ITC Hotels'), __('ITC Hotels'));

         return $resultPage;
    }

 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('ITC_Hotels::hotels1');
    }
}

?>
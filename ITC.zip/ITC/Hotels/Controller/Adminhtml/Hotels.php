<?php
namespace ITC\Hotels\Controller\Adminhtml;

abstract class Hotels extends \Magento\Backend\App\Action
{
    protected $_coreRegistry;
	const ADMIN_RESOURCE = 'ITC_HOTELS::hotels';
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
		\Magento\Backend\App\Action\Context $context, 
		\Magento\Framework\Registry $coreRegistry
	)
    {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    /**
     * Check if admin has permissions to visit related pages.
     *
     * @return bool
     */
  /*  protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('ITC_Hotels::hotels');
    } */
	
	 /**
     * Init Hotels
     *
     * @return \ITC\Hotels\Model\Hotels
     */
    protected function _initPost()
	{
		
		$resultPage->setActiveMenu('ITC_Hotels::itc_hotels')
            ->addBreadcrumb(__('HOTELS'), __('HOTELS'))
            ->addBreadcrumb(__('Static Blocks'), __('Static Blocks'));
        return $resultPage;

    }
}
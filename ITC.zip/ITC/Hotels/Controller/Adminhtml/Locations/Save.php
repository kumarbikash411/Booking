<?php

namespace ITC\Hotels\Controller\Adminhtml\Locations;

use Magento\Framework\App\Filesystem\DirectoryList;
use ITC\Hotels\Model\Locations;

class Save extends \ITC\Hotels\Controller\Adminhtml\Locations
{

    public function execute()
    {
       $resultRedirect = $this->resultRedirectFactory->create();
	   
	   $data = $this->getRequest()->getPostValue();
	   
       if (isset($data['contact'])) {
		    $model = $this->_objectManager->create('ITC\Hotels\Model\Locations');			
			$model->setData($data['contact']);  	
			$model->save();
	   }   
	   $this->_redirect('*/*/');
    }
}

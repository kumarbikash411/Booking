<?php



namespace ITC\Hotels\Controller\Adminhtml\Index;


class Grid extends \ITC\Hotels\Controller\Adminhtml\Room
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
        $resultLayout = $this->_resultLayoutFactory->create();

        return $resultLayout;
    }
}

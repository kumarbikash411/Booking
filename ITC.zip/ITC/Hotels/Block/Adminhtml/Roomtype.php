<?php 
namespace ITC\Hotels\Block\Adminhtml;

class Roomtype extends \Magento\Backend\Block\Widget\Container
{
	/**
	 * @var string
	 */
	protected $_template = 'roomtype/view.phtml';

	/**
	 * @param \Magento\Backend\Block\Widget\Context $context
	 * @param array $data
	 */
	public function __construct(
			\Magento\Backend\Block\Widget\Context $context,
			array $data = []
	) {
		parent::__construct($context, $data);
		$this->_getAddButtonOptions();
	}

	/**
	 * Prepare button and gridCreate Grid , edit/add grid row and installer in Magento2
	 *
	 * @return \Magento\Catalog\Block\Adminhtml\Product
	 */
	protected function _prepareLayout()
	{	
		$this->setChild(
				'grid',
				$this->getLayout()->createBlock('ITC\Hotels\Block\Adminhtml\Roomtype\Grid', 'grid.view.grid')
		);
		return parent::_prepareLayout();
	}

	/**
	 *
	 *
	 * @return array
	 */
	protected function _getAddButtonOptions()
	{
		$splitButtonOptions = [
		'label' => __('Add New Room Type'),
		'class' => 'primary',
		'onclick' => "setLocation('" . $this->_getCreateUrl() . "')"
				];
		$this->buttonList->add('add', $splitButtonOptions);
		
	}

	protected function _getCreateUrl()
	{
		return $this->getUrl(
				'hotels/*/new'
		); 
	}


	/**
	 * Render grid
	 *
	 * @return string
	 */
	public function getGridHtml()
	{
		return $this->getChildHtml('grid');
	}
}
<?php 
 
namespace ITC\Hotels\Block\Adminhtml\Roomtype\Edit\Tab;

 
class Settings extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface

{

    protected $_systemStore;


    protected $_wysiwygConfig;

 
    public function __construct(

        \Magento\Backend\Block\Template\Context $context,

        \Magento\Framework\Registry $registry,

        \Magento\Framework\Data\FormFactory $formFactory,

        \Magento\Store\Model\System\Store $systemStore,

        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,

        array $data = []

    ) {

        $this->_systemStore = $systemStore;

        $this->_wysiwygConfig = $wysiwygConfig;

        parent::__construct($context, $registry, $formFactory, $data);

    }


    protected function _prepareForm()

    {

    	

        $model = $this->_coreRegistry->registry('itc_form_post_data');

        $isElementDisabled = false;

 

 		

 		

        /** @var \Magento\Framework\Data\Form $form */

        $form = $this->_formFactory->create();

 

        $form->setHtmlIdPrefix('page_');

 

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('SEO INFORMATION')]);

        

        

         $fieldset->addField(

        		'meta_title',

        		'text',

        		[

        		'name' => 'meta_title',

        		'label' => __('Meta title'),

        		'title' => __('store'),

        		'disabled' => $isElementDisabled

        		]

        ); 

        

         $fieldset->addField(

         		'meta_description',

         		'textarea',

         		[

         		'name' => 'meta_description',

         		'label' => __('Meta Keywords'),

         		'title' => __('keywords'),

         		'disabled' => $isElementDisabled,

         		//'config' => $wysiwygConfig

         		]

         );

         

         

        $fieldset->addField(

                'meta_content',

                'textarea',

                [

                'name' => 'meta_content',

                'label' => __('Meta Description'),

                'title' => __('Sort Order'),

        		'note' => __('meta description limit should not be more than 255 '),

                'disabled' => $isElementDisabled

                ]

        );

        //$wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);

        

       

      

        /* if (!$model->getId()) {

            $model->setData('is_active', $isElementDisabled ? '0' : '1');

        }

 

        $form->setValues($model->getData()); */

        $this->setForm($form);

 

        return parent::_prepareForm();

    }

 

    /**

     * Prepare label for tab

     *

     * @return \Magento\Framework\Phrase

     */

    public function getTabLabel()

    {

        return __('Meta Description');

    }

 

    /**

     * Prepare title for tab

     *

     * @return \Magento\Framework\Phrase

     */

    public function getTabTitle()

    {

        return __('Description');

    }

 

    /**

     * {@inheritdoc}

     */

    public function canShowTab()

    {

        return true;

    }

 

    /**

     * {@inheritdoc}

     */

    public function isHidden()

    {

        return false;

    }

 

    /**

     * Check permission for passed action

     *

     * @param string $resourceId

     * @return bool

     */

    protected function _isAllowedAction($resourceId)

    {

        return $this->_authorization->isAllowed($resourceId);

    }

}
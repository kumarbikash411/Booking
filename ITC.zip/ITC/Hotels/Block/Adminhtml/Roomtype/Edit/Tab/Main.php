<?php 
/**
 * ITCCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the 
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
  * http://itccommerce.com/license-agreement.txt
 *
 * @category    ITC
 * @package     ITC_Hotels
 * @author      ITCCommerce Core Team <connect@itccommerce.com >
 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)
 * @license      http://itccommerce.com/license-agreement.txt
 */

 
namespace ITC\Hotels\Block\Adminhtml\Roomtype\Edit\Tab;
 
/**
 * Blog post edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;
 
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $categorymodel = $objectManager->create('ITC\Hotels\Model\RoomTypeCategory')->getCollection();


        $roomTypeRegistry = $this->_coreRegistry->registry('itc_roomtype_data');

        $roomCategoryRelationData = $objectManager->create('ITC\Hotels\Model\RoomCategoryRelation')->getCollection()->addFieldToFilter('room_type_id',$roomTypeRegistry->getId());

        $roomTypecategoryIds = $roomCategoryRelationData->getColumnValues('room_category_id');
        $isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
 
        $form->setHtmlIdPrefix('page_');
 
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Basic Information')]);
 
        
        $fieldset->addField('id', 'hidden', ['name' => 'id']);
     
        
         $fieldset->addField(
            'rtype_id',
            'text',
            [
                'name' => 'rtype_id',
                'label' => __('RoomTypeID'),
                'title' => __('RoomTypeID'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
         $fieldset->addField(
            'rtype_name',
            'text',
            [
                'name' => 'rtype_name',
                'label' => __('RoomTypeName'),
                'title' => __('RoomTypeName'),
                'disabled' => $isElementDisabled
            ]
        );
         $fieldset->addField(
            'rtype_descrtype_desc',
            'textarea',
            [
                'name' => 'rtype_descrtype_desc',
                'label' => __('Room Type Description'),
                'title' => __('Room Type Description'),
                'disabled' => $isElementDisabled
            ]
        );
      //  $arr=['1'=>'Enabled','0'=>'Disabled'];
      //  $fieldset->addField('status',
           // 'select',
             //   [
              //      'name' => 'status',
               //     'label' => __('Status'),
                //    'title' => __('Status'),
                //    'disabled' => $isElementDisabled,
                 //   'values'=>  $arr
         
              //  ]);
            if (count($categorymodel) != 0) {

                foreach ($categorymodel as $category) {
               
                    $catarr[] = ['label'=>$category->getTitle(),
                                 'value'=>$category->getId()];
                } 
            } else {
                $catarr = Null;
            }

          //  $fieldset->addField('category_id',
          //  'multiselect',
             //   [
                  //      'name' => 'category_id[]',
                  //      'label' => __('Category'),
                  //      'title' => __('Category'),
                   //     'required' => true,
                    //    'disabled' => $isElementDisabled,
                     //   'values'=>  $catarr
         
              //  ]);
        $roomTypeRegistry->setCategoryId($roomTypecategoryIds);
        $form->setValues($roomTypeRegistry->getData());
        $this->setForm($form);
  
        return parent::_prepareForm();
    }
 
    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Basic Settings');
    }
 
    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Basic Settings');
    }
 
    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
 
    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
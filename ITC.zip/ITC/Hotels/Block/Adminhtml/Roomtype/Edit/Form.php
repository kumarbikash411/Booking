<?php 
/**
 * ITCCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the 
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
  * http://itccommerce.com/license-agreement.txt
 *
 * @category    ITC
 * @package     ITC_Hotels
 * @author      ITCCommerce Core Team <connect@itccommerce.com >
 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)
 * @license      http://itccommerce.com/license-agreement.txt
 */

 
namespace ITC\Hotels\Block\Adminhtml\Roomtype\Edit;
 
/**
 * Adminhtml grid record edit form block
 *
 * 
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
    	
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post','enctype' => 'multipart/form-data']]
        );
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
       
    }
}
<?php 

/**

 * ITCCommerce

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the 

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://itccommerce.com/license-agreement.txt

 *

 * @category    ITC

 * @package     ITC_Hotels

 * @author   ITCCommerce Magento Core Team <ITC_MagentoCoreTeam@itccommerce.com>

 * @copyright   Copyright ITCCommerce (http://itccommerce.com/)

 * @license      http://itccommerce.com/license-agreement.txt

 */



namespace ITC\Hotels\Block\Adminhtml\Roomtype\RoomtypeRender\Grid\Renderer;


class Status extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer

{
    /**
     * 
     * @var unknown
     */
	protected $_storeManager;
    
	/**
	 * (non-PHPdoc)
	 * @see \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer::render()
	 */
	public function render(\Magento\Framework\DataObject $row)
	{   
		if ($row->getRoomtypeStatus() == '1') {
			$html='Enabled';
			return $html;
		} else {
			$html='Disabled';
			return $html;
		}
	}
}

<?php 


namespace ITC\Hotels\Block\Adminhtml\Amenties\AmentyRender\Grid\Renderer;



class Status extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer

{

	protected $_storeManager;

	public function render(\Magento\Framework\DataObject $row)

	{   
		if ($row->getStatus() == '1') {
			$html='Enabled';
			return $html;
		} else {
			$html='Disabled';
			return $html;
		}
	}

}



?>
<?php 
    
namespace ITC\Hotels\Block\Adminhtml\Amenties\Edit\Tab;



class Amenties extends \Magento\Backend\Block\Widget\Container

{

	protected $_template = 'grid/view.phtml';

	public function __construct(

			\Magento\Backend\Block\Widget\Context $context,

			array $data = []

	) {

		

		parent::__construct($context, $data);

		$this->_getAddButtonOptions();

	}


	protected function _prepareLayout()

	{

		$this->setChild(

				'grid',

				$this->getLayout()->createBlock('ITC\Hotels\Block\Adminhtml\Amenties\Edit\Tab\ProductGrid\Grid', 'grid.view.grid')

		);

		

		return parent::_prepareLayout();

	}


	protected function _getAddButtonOptions()

	{

		$splitButtonOptions = [

		'label' => __('Add New Post'),

		'class' => 'primary',

		'onclick' => "setLocation('" . $this->_getCreateUrl() . "')"

				];

		$this->buttonList->add('add', $splitButtonOptions);

	}



	protected function _getCreateUrl()

	{

		return $this->getUrl(

				'hotels/*/new'

		);

	}


	public function getGridHtml()

	{

		return $this->getChildHtml('grid');

	}

	

}
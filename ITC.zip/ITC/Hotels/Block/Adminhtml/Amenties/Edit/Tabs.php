<?php 

namespace ITC\Hotels\Block\Adminhtml\Amenties\Edit;
 
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Framework\Json\EncoderInterface;



class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
        parent::_construct();
        $this->setId('id');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Ammenties Information'));
    
    }   
   
    
    
    public function __construct(
    		Context $context,
    		EncoderInterface $jsonEncoder,
    		Session $authSession,
    		\Magento\Framework\ObjectManagerInterface $objectManager,
    		array $data = []
    )
    {
    	
    	parent::__construct($context, $jsonEncoder, $authSession, $data);
    	$this->_objectManager = $objectManager;
    }
    protected function _beforeToHtml()
    {
    		
    	$this->addTab('General', array(
    				'label'     => __('Ammenties'),
    				'title'     => __('Ammenties'),
    				'content'   => $this->getLayout()->createBlock('ITC\Hotels\Block\Adminhtml\Amenties\Edit\Tab\Main')->toHtml(),
    		));
		 
    	return parent::_beforeToHtml();
    }
    
}
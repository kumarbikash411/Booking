<?php



namespace ITC\Hotels\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Install schema
 * @category ITC
 * @package  ITC_Hotels
 * @module   Hotels
 * @author   ITC Developer
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        /*
         * Drop tables if exists
        */
        

        /*
         * Create table itc_location
        */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_location')
        )->addColumn(
            'lid',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Location ID'
        )->addColumn(
            'lname',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false, 'default' => ''],
            'Location Name'
        )->addColumn(
            'status',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           1,
           [],
           'Status'
        )->addIndex(
            $installer->getIdxName('itc_location', ['lid']),
            ['lid']       
        );
        $installer->getConnection()->createTable($table);
		
		/*
         * Create table itc_hotels
        */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_hotels')
        )->addColumn(
            'hid',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'identity' => true,'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Hotel ID'
        )->addColumn(
            'hcode',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Hotel Code'        
        )->addColumn(
            'hname',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Hotel Name'        
        )->addColumn(
            'hclass',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Hotel Class'        
        )->addColumn(
            'locationid',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Location ID'
        )->addColumn(
            'status',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           1,
           [],
           'Status'
        )->addForeignKey(
            $installer->getFkName(
                'itc_hotels',
                'locationid',
                'itc_location',
                'lid'
            ),
            'locationid',
            $installer->getTable('itc_location'),
            'lid',
            \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
		);			
        $installer->getConnection()->createTable($table);
		
		/*
         * Create table itc_room_type
        */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_room_type')
        )->addColumn(
            'rtype_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Room Type ID'
        )->addColumn(
            'rtype_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Type Name'        
        )->addColumn(
            'rtype_descrtype_desc',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Type Description'        
        )->addColumn(
            'status',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           1,
           [],
           'Status'
        );		
        $installer->getConnection()->createTable($table);
		
		/*
         * Create table itc_amenities
        */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_amenities')
        )->addColumn(
            'amenity_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Amenity ID'
        )->addColumn(
            'amenity_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Amenity Name'        
        )->addColumn(
            'amenity_icon',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Amenity Icon'        
        )->addColumn(
            'amenity_desc',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Amenity Description'        
        )->addColumn(
            'status',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           1,
           [],
           'Status'
        );			
        $installer->getConnection()->createTable($table);
		
		/*
         * Create table itc_room_amenities
        */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_room_amenities')
        )->addColumn(
            'ra_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Room Amenity Id'
        )->addColumn(
            'room_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Id'        
        )->addColumn(
            'amenity_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Amenity ID'        
        )->addColumn(
            'status',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           1,
           [],
           'Status'
        )->addForeignKey(
            $installer->getFkName(
                'itc_room_amenities',
                'ra_id',
                'itc_rooms',
                'rooms_id'
            ),
            'ra_id',
            $installer->getTable('itc_rooms'),
            'rooms_id',
            \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
		)->addForeignKey(
            $installer->getFkName(
                'itc_room_amenities',
                'amenity_id',
                'itc_amenities',
                'amenity_id'
            ),
            'amenity_id',
            $installer->getTable('itc_amenities'),
            'amenity_id',
            \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
		);			
        $installer->getConnection()->createTable($table);
		
		/*
         * Create table itc_rooms
        */
        
        
        
        $table = $installer->getConnection()->newTable(
            $installer->getTable('itc_rooms')
        )->addColumn(
            'rooms_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Rooms ID'
        )->addColumn(
            'room_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Name'        
        )->addColumn(
            'room_no',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Number'        
        )->addColumn(
            'room_desc',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            50,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Description'        
        )->addColumn(
            'room_price',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Price'        
        )->addColumn(
            'max_adultcount',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Max Adult Count'        
        )->addColumn(
            'max_childcount',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Max Children Count'        
        )->addColumn(
            'hid',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Hotel ID'        
        )->addColumn(
                'rtype_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            10,
            [ 'unsigned' => true, 'nullable' => false],            
            'Room Type ID'        
        )->addColumn(
            'galleryID',
           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
           10,
           [],
           'Gallery ID '
        )->addForeignKey(
            $installer->getFkName(
                'itc_rooms',
                'hid',
                'itc_hotels',
                'hid'
            ),
            'hid',
            $installer->getTable('itc_hotels'),
            'hid',
            \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
		)->addForeignKey(
            $installer->getFkName(
                'itc_rooms',
                'rtype_id',
                'itc_room_type',
                'rtype_id'
            ),
            'rtype_id',
            $installer->getTable('itc_room_type'),
            'rtype_id',
            \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
		);			
        $installer->getConnection()->createTable($table);
		
        $installer->endSetup();
    }
}